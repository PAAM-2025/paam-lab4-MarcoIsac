package com.example.lab_4.domain

data class Chiuit(val timestamp : Long, val description : String)